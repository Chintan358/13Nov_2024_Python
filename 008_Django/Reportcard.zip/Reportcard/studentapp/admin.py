from django.contrib import admin
from studentapp.models import *
# Register your models here.

admin.site.register(Department)
admin.site.register(StudentId)
admin.site.register(Student)
admin.site.register(Subject)
admin.site.register(Marks)
